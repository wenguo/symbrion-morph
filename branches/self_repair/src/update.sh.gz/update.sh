#!/bin/sh
gunzip scout_option.cfg.20.gz
mv scout_option.cfg.20 scout_option.cfg
