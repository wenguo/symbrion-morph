#!/bin/sh
gunzip scout_option.cfg.12.gz
mv scout_option.cfg.12 scout_option.cfg
