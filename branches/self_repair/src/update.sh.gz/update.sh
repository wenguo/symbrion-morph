#!/bin/sh
gunzip scout_option.cfg.16.gz
mv scout_option.cfg.16 scout_option.cfg
