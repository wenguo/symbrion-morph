#!/bin/sh
gunzip scout_option.cfg.11.gz
mv scout_option.cfg.11 scout_option.cfg
