#!/bin/sh
gunzip kit_option.cfg.59.gz
mv kit_option.cfg.59 kit_option.cfg
