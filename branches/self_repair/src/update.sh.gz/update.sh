#!/bin/sh
gunzip aw_option.cfg.6.gz
mv aw_option.cfg.6 aw_option.cfg
