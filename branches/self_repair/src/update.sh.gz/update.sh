#!/bin/sh
gunzip scout_option.cfg.10.gz
mv scout_option.cfg.10 scout_option.cfg
