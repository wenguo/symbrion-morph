#!/bin/sh
gunzip aw_option.cfg.2.gz
mv aw_option.cfg.2 aw_option.cfg
