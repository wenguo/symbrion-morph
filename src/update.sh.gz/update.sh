#!/bin/sh
rm scout_option.cfg
gunzip scout_option.cfg.gz
