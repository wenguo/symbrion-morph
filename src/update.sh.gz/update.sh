#!/bin/sh
gunzip scout_option.cfg.8.gz
mv scout_option.cfg.8 scout_option.cfg
