#!/bin/sh
gunzip scout_option.cfg.7.gz
mv scout_option.cfg.7 scout_option.cfg
