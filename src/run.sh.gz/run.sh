#!/bin/sh
export LD_LIBRARY_PATH=/flash/morph/
export SCOUT_SPI_GPIO_FIX=1
/flash/morph/morph 
